<?php
// File where appointments are saved
$file = 'appointments.txt';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Appointments</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <style>
        body { padding: 30px; background-color: #f9f9f9; }
        table { background: #fff; border-radius: 5px; }
        th, td { text-align: center; }
        h2 { margin-bottom: 20px; }
        .back-btn { margin-top: 20px; }
    </style>
</head>
<body>

<div class="container">
    <h2>All Appointments</h2>

    <?php if (!file_exists($file) || filesize($file) == 0): ?>
        <p>No appointments have been booked yet.</p>
    <?php else: ?>
        <table class="table table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Date</th>
                    <th>Message</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $lines = file($file, FILE_IGNORE_NEW_LINES);
                foreach ($lines as $line) {
                    $data = explode(",", $line);
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($data[0]) . "</td>";
                    echo "<td>" . htmlspecialchars($data[1]) . "</td>";
                    echo "<td>" . htmlspecialchars($data[2]) . "</td>";
                    echo "<td>" . htmlspecialchars($data[3]) . "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    <?php endif; ?>

    <a href="index.html" class="btn btn-primary back-btn">Back to Home</a>
</div>

</body>
</html>
