using System;
using System.Web.UI;

public partial class login : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Page load stub. Currently the page uses client-side storage for demo login/registration.
        // Add server-side authentication logic here if you want to perform real auth.
    }
}
