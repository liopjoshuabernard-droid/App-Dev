document.getElementById("bookForm").addEventListener("submit", function(e){
    e.preventDefault();

    const name = document.getElementById("customerName").value;
    const email = document.getElementById("customerEmail").value;
    const phone = document.getElementById("customerPhone").value;
    const service = document.getElementById("serviceSelect").value;
    const date = document.getElementById("appointmentDate").value;
    const time = document.getElementById("appointmentTime").value;
    const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked')?.value;

    if (!service) {
        Swal.fire({
            title: "Oops!",
            text: "Please select a service.",
            icon: "warning",
            confirmButtonColor: "#E598A9"
        });
        return;
    }

    if (!paymentMethod) {
        Swal.fire({
            title: "Payment Required",
            text: "Please select a payment method.",
            icon: "warning",
            confirmButtonColor: "#E598A9"
        });
        return;
    }

    // Store appointment
    const appointment = { name, email, phone, service, date, time, paymentMethod };
    let appointments = JSON.parse(localStorage.getItem("appointments") || "[]");
    appointments.push(appointment);
    localStorage.setItem("appointments", JSON.stringify(appointments));

    // Success message with payment info
    Swal.fire({
        title: "Booking & Payment Successful!",
        html: `Thank you, <b>${name}</b>.<br>Your appointment for <b>${service}</b> is scheduled on <b>${date}</b> at <b>${time}</b>.<br>Payment Method: <b>${paymentMethod}</b>`,
        icon: "success",
        confirmButtonColor: "#E598A9"
    });

    this.reset();
});
