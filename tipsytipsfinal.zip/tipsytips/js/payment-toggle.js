document.addEventListener("DOMContentLoaded", function () {
  const cardFields = document.querySelector(".card-details");
  const gcashFields = document.querySelector(".gcash-details");
  const paymentRadios = document.querySelectorAll('input[name="paymentMethod"]');

  // Initialize visibility
  cardFields.style.display = "none";
  gcashFields.style.display = "none";

  paymentRadios.forEach(radio => {
    radio.addEventListener("change", () => {
      if (radio.value === "Card") {
        cardFields.style.display = "block";
        gcashFields.style.display = "none";

        // Enable card input required
        cardFields.querySelectorAll("input").forEach(input => input.required = true);
        // Disable Gcash input required
        gcashFields.querySelectorAll("input").forEach(input => input.required = false);
      } else if (radio.value === "Gcash") {
        cardFields.style.display = "none";
        gcashFields.style.display = "block";

        // Enable Gcash input required
        gcashFields.querySelectorAll("input").forEach(input => input.required = true);
        // Disable card input required
        cardFields.querySelectorAll("input").forEach(input => input.required = false);
      }

   function showTab(n) {
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  document.querySelector(".prev-btn").style.display = n == 0 ? "none" : "inline";

  const nextBtn = document.querySelector(".next-btn");
  if (n == (x.length - 1)) {
    nextBtn.innerHTML = "Book Now";
    nextBtn.classList.add("book-now");
  } else {
    nextBtn.innerHTML = "Next";
    nextBtn.classList.remove("book-now");
  }

  fixStepIndicator(n);
}



    });
  });
});

