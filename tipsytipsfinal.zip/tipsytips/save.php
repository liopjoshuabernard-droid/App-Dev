<?php
// save.php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $service = $_POST['service'] ?? '';
    $date = $_POST['date'] ?? '';
    $time = $_POST['time'] ?? '';
    $message = $_POST['message'] ?? '';

    $appointment = [
        'name' => $name,
        'email' => $email,
        'service' => $service,
        'date' => $date,
        'time' => $time,
        'message' => $message
    ];

    $line = json_encode($appointment) . PHP_EOL;

    file_put_contents('appointments.txt', $line, FILE_APPEND | LOCK_EX);

    echo "success";
}
?>
