<%@ Page Language="C#" AutoEventWireup="true" CodeFile="login.aspx.cs" Inherits="login" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login/Register - TipsyTips Salon</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css"> <!-- Your main CSS -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="login-bg">

  <form id="form1" runat="server">

    <!-- Logo Top -->
    <div class="logo_section">
      <div class="full">
        <div class="center-desk">
          <div class="logo">
            <a href="index.html"><img src="images/logos.png" alt="Milina Logo" /></a>
          </div>
        </div>
      </div>
    </div>

    <!-- Login/Register Card -->
    <div class="login-card">
      <h2 id="formTitle">Client Login</h2>

      <!-- Login Form (converted to div to avoid nested <form> inside server form) -->
      <div id="loginForm" role="form">
        <input type="email" class="login-input" id="loginEmail" placeholder="Email Address" required>
        <input type="password" class="login-input" id="loginPassword" placeholder="Password" required>
        <button type="button" class="login-btn" id="loginSubmitBtn">Login</button>
        <p class="text-center mt-2">Don't have an account? 
          <span class="toggle-link" id="showRegister">Register here</span>
        </p>
      </div>

      <!-- Register Form (converted to div) -->
      <div id="registerForm" class="hidden" role="form">
        <input type="text" class="login-input" id="regName" placeholder="Full Name" required>
        <input type="email" class="login-input" id="regEmail" placeholder="Email Address" required>
        <input type="password" class="login-input" id="regPassword" placeholder="Password" required>
        <input type="password" class="login-input" id="regConfirmPassword" placeholder="Confirm Password" required>
        <button type="button" class="login-btn" id="registerSubmitBtn">Register</button>
        <p class="text-center mt-2">Already have an account? 
          <span class="toggle-link" id="showLogin">Login here</span>
        </p>
      </div>

      <a href="index.html" class="back-home">← Back to Home</a>
    </div>

    <!-- Scripts -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>

    <script>
      // Demo account (client-side demo behaviour retained)
      const account = {
        email: "liopjosh@gmail.com",
        password: "12345",
        name: "Joshua User"
      };

      const loginDiv = document.getElementById("loginForm");
      const registerDiv = document.getElementById("registerForm");
      const formTitle = document.getElementById("formTitle");

      // Toggle forms
      document.getElementById("showRegister").addEventListener("click", function(){
        loginDiv.classList.add("hidden");
        registerDiv.classList.remove("hidden");
        formTitle.innerText = "Client Register";
      });
      document.getElementById("showLogin").addEventListener("click", function(){
        registerDiv.classList.add("hidden");
        loginDiv.classList.remove("hidden");
        formTitle.innerText = "Client Login";
      });

      // Login button handler
      document.getElementById("loginSubmitBtn").addEventListener("click", function(e){
        let email = document.getElementById("loginEmail").value;
        let password = document.getElementById("loginPassword").value;

        if(email === account.email && password === account.password){
          localStorage.setItem("userName", account.name);
          Swal.fire({
            title: "Login Successful!",
            text: "Welcome, " + account.name,
            icon: "success",
            confirmButtonColor: "#E598A9"
          }).then(() => {
            window.location.href = "index.html";
          });
        } else {
          Swal.fire({
            title: "Login Failed",
            text: "Incorrect email or password.",
            icon: "error"
          });
        }
      });

      // Register button handler
      document.getElementById("registerSubmitBtn").addEventListener("click", function(e){
        let name = document.getElementById("regName").value;
        let email = document.getElementById("regEmail").value;
        let password = document.getElementById("regPassword").value;
        let confirmPassword = document.getElementById("regConfirmPassword").value;

        if(password !== confirmPassword){
          Swal.fire({
            title: "Registration Failed",
            text: "Passwords do not match.",
            icon: "error"
          });
          return;
        }

        localStorage.setItem("userName", name);
        localStorage.setItem("userEmail", email);
        localStorage.setItem("userPassword", password);

        Swal.fire({
          title: "Registration Successful!",
          text: "Welcome, " + name,
          icon: "success",
          confirmButtonColor: "#E598A9"
        }).then(() => {
          document.getElementById("showLogin").click();
        });
      });
    </script>

  </form>

</body>
</html>
