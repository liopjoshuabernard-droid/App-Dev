<?php
// admin_dashboard.php

// Read appointments from TXT
$appointments = file_exists('appointments.txt') ? file('appointments.txt', FILE_IGNORE_NEW_LINES) : [];

// Read users from TXT
$users = file_exists('users.txt') ? file('users.txt', FILE_IGNORE_NEW_LINES) : [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard - TipsyTips Salon</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <style>
    body { font-family: Arial, sans-serif; background: #f2f2f2; padding: 20px; }
    h2 { color: #E598A9; margin-bottom: 20px; text-align: center; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 40px; }
    th, td { border: 1px solid #ddd; padding: 10px; text-align: center; }
    th { background-color: #E598A9; color: white; }
    tr:nth-child(even) { background-color: #f9f9f9; }
    .btn-back { display: inline-block; margin-bottom: 20px; padding: 10px 20px; background: #E598A9; color: white; text-decoration: none; border-radius: 25px; }
    .btn-back:hover { background: #d17e94; }
  </style>
</head>
<body>
  <a href="login.html" class="btn-back">← Logout</a>
  <h2>Admin Dashboard</h2>

  <h3>Appointments</h3>
  <table>
    <thead>
      <tr>
        <th>Client Name</th>
        <th>Email</th>
        <th>Service</th>
        <th>Date</th>
        <th>Time</th>
      </tr>
    </thead>
    <tbody>
      <?php
      if(count($appointments) > 0){
        foreach($appointments as $line){
          list($name,$email,$service,$date,$time) = explode(',', $line);
          echo "<tr><td>$name</td><td>$email</td><td>$service</td><td>$date</td><td>$time</td></tr>";
        }
      } else {
        echo "<tr><td colspan='5'>No appointments yet.</td></tr>";
      }
      ?>
    </tbody>
  </table>

  <h3>Registered Users</h3>
  <table>
    <thead>
      <tr>
        <th>Name</th>
        <th>Email</th>
        <th>Password</th>
      </tr>
    </thead>
    <tbody>
      <?php
      if(count($users) > 0){
        foreach($users as $line){
          list($name,$email,$password) = explode(',', $line);
          echo "<tr><td>$name</td><td>$email</td><td>$password</td></tr>";
        }
      } else {
        echo "<tr><td colspan='3'>No users yet.</td></tr>";
      }
      ?>
    </tbody>
  </table>
</body>
</html>
